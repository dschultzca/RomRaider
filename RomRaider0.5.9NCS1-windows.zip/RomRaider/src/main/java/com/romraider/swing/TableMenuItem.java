package com.romraider.swing;

import javax.swing.JRadioButtonMenuItem;

public class TableMenuItem extends JRadioButtonMenuItem{

    private static final long serialVersionUID = -3618983591185294967L;

    public TableMenuItem(String itemName) {
        super(itemName);
    }
}
